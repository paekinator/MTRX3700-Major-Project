[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$')]
    [string]$Tag = ('grab_' + (Get-Date -Format 'yyyyMMdd_HHmmss')),
    [switch]$Held,
    [switch]$CheckOnly,
    [switch]$CheckPartA,
    [string]$QuartusBin = 'C:\intelFPGA_lite\18.1\quartus\bin64',
    [string]$PythonExe = 'C:\Users\Nebula PC\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
)
# Requires an ECHO Part A camera image with raw FrameGrab already running.
# CheckPartA requires the NEW 77-word PartAPipeline build, not the calibration build.
# This helper never programs the
# board, changes pins, writes flash, or sends chassis commands.
$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'calibration'
$destination = Join-Path (Join-Path $PSScriptRoot 'captures') $Tag
$stp = Join-Path $QuartusBin 'quartus_stp.exe'
$decoder = Join-Path $project 'tools/grab.py'
$tcl = Join-Path $project 'tcl/grab_jtag.tcl'
$partAChecker = Join-Path $PSScriptRoot 'pipeline/tools/part_a/check_hardware_packet.py'
$partAV2Checker = Join-Path $PSScriptRoot 'pipeline-v2/tools/part_a/check_hardware_packet.py'
if (Test-Path -LiteralPath $partAV2Checker -PathType Leaf) { $partAChecker = $partAV2Checker }
foreach ($requiredFile in @($stp,$PythonExe,$decoder,$tcl)) {
    if (-not (Test-Path -LiteralPath $requiredFile -PathType Leaf)) { throw "Missing: $requiredFile" }
}
if ($CheckPartA -and -not (Test-Path -LiteralPath $partAChecker -PathType Leaf)) { throw "Missing checker: $partAChecker" }
if (Test-Path -LiteralPath $destination) { throw "Choose a fresh Tag; folder exists: $destination" }
& $PythonExe -c 'import numpy; from PIL import Image; print("Capture dependencies OK")'
if ($LASTEXITCODE -ne 0) { throw 'Python dependencies unavailable.' }
if ($CheckOnly) { Write-Output "Ready: $destination (no board access performed)"; return }
$captureArgs = @('-t',$tcl,$destination,'--mvfp','0x07')
if ($Held) { $captureArgs += '--held' }
& $stp @captureArgs
if ($LASTEXITCODE -ne 0) { throw 'JTAG acquisition failed; inspect capture log.' }
$dump = Join-Path $destination 'dump.bin'
if (-not (Test-Path -LiteralPath $dump -PathType Leaf)) { throw 'No dump.bin was acquired.' }
& $PythonExe $decoder --file $dump --out $destination --mvfp 0x07
if ($LASTEXITCODE -ne 0) { throw 'Decoding or CRC check failed.' }
if ($CheckPartA) {
    & $PythonExe $partAChecker $destination
    if ($LASTEXITCODE -ne 0) { throw 'Part A measured results do not match the golden model; inspect part-a-hardware-check.json.' }
}
Write-Output "Saved: $(Join-Path $destination 'frame.png')"
