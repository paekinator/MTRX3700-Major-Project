ECHO-7 isolated native Windows simulation runtime
================================================

ARCHIVE NOTE: this README was copied from work/parta_sim. Run the commands below
from C:/Users/Nebula PC/Documents/Codex/2026-10-28/pl. The runnable helpers remain
in work/parta_sim; this verification folder contains the saved evidence/logs.

The runnable helper is run_local_tests.py in this directory. It builds the
current source files without changing them. Build projects, binaries, hashes
and logs stay under work/parta_sim/runs/<UTC timestamp>/.

From the workspace directory in PowerShell:

  & 'work/rtl_runtime/Scripts/python.exe' 'work/parta_sim/run_local_tests.py' --tests hello cleanup_centroid boundedCandidates candidate_mutant pipeline

Individual targets can be selected in the same way. Any failed normal test,
missing tool or uncaught mutation makes the helper exit nonzero. The mutation
target edits only a temporary copy and prints CAUGHT only for the expected
cx-field mismatch plus a nonzero simulator status; the original RTL's hash is
checked again afterwards.

To repeat the timed complete Part A invocation (15 Python unit tests, fresh BFS
vectors, then cleanup_centroid, boundedCandidates, pipeline and candidate_mutant
in fresh build directories):

  & 'work/rtl_runtime/Scripts/python.exe' 'work/parta_sim/run_timed_suite.py'

The 29 October 2026 run completed successfully in 122.109 seconds. Its full
summary is timed/20261029T004957516082Z/summary.json. All normal RTL tests passed,
the deliberate cx+1 mutation was caught with simulator exit 1 and the expected
field-6 mismatch, all source files stayed unchanged, and all four canonical core
files matched the pipeline copies by SHA-256. Tool installation is excluded;
fresh vectors and all configure/build/simulation stages are included. Installed
compiler/toolchain caches may be reused, while each test project/build is new.

Installed only inside the workspace venv work/rtl_runtime:
  verilator-dspsim==5.50.1
  cmake==4.4.4
  ninja==1.13.2
  ziglang==0.14.1

Primary package sources:
  https://pypi.org/project/verilator-dspsim/5.50.1/
  https://github.com/fsodari/verilator-python
  https://pypi.org/project/cmake/4.4.4/
  https://pypi.org/project/ninja/1.13.2/
  https://pypi.org/project/ziglang/0.14.1/

Verilator's executable banner in this third-party wheel is "rev v5.050".
Its generated simulation reports "Verilator 5.50". The helper checks v5.050
explicitly. It uses Verilator --main --timing --assert and its supported CMake
JSON integration, followed by Ninja and Zig's standalone C++20 compiler. This
is the timed executable workflow corresponding to --binary; it does not invoke
the GNU-make-based --binary shortcut on Windows.

Why this route: the existing Visual Studio compiler is present, but required
Windows SDK tools (rc.exe and mt.exe) were not found by its CMake link probe.
Zig supplies the Windows GNU target's
C/C++ development files in the venv, so no Visual Studio/SDK installation or
system PATH changes were needed. Both Zig caches are redirected into the venv
by each child process. The package's path parsing needs space-free paths, so the
helper uses this machine's NTFS short directory aliases and preserves original
source filenames (including their lower-case .sv extension).

If recreating the venv on this same machine, use the bundled Python:

  & 'C:/Users/Nebula PC/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -m venv 'work/rtl_runtime'
  & 'work/rtl_runtime/Scripts/python.exe' -m pip install 'verilator-dspsim==5.50.1' 'cmake==4.4.4' 'ninja==1.13.2' 'ziglang==0.14.1'

Do not overwrite an existing venv merely to rerun tests. No WSL, global Python
packages or global PATH changes are required. No UI or hardware is controlled.

This is a Part A development check, not proof that the complete robot meets R6
or that hardware behaviour agrees. The submission still needs the portable
whole-project runner, system tests, hardware replay and board verification.
