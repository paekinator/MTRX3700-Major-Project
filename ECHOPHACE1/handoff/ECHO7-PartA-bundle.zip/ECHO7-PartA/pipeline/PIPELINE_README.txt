ECHO-7 PART A: NATIVE COLOUR AND CANDIDATE PIPELINE
Human owner: Member A (name/SID pending). AI-assisted by OpenAI Codex.

This standalone project extends the separate calibration build. It performs
native-camera colour classification, raw colour centroids, causal mask cleanup,
and bounded colour candidate extraction. It contains no CNN, candidate association,
chassis UART, motion requests, sonar, Arduino control, or IR control.
Compilation, simulation, timing, and board validation are separate checks; consult
their recorded reports. A generated source directory alone is not hardware evidence.

DATA PATH
  Raw OV7670 capture -> keep even x/even y -> native 320x240 RGB565.
  Existing segmentationSelector selects fixed RGB, ratio RGB, or HSV; it debounces
  the switch controls and latches each frame's selection at the native SOP.
  Native coordinates receive the same three-clock delay as classification.
  RawColourCentroid counts every classified red/blue pixel and computes exact floor
  sum/area centroids before cleanup. Its background/distractor sensitivity is intentional.
  CausalMaskCleanup retains a foreground pixel if its raw left or raw upper neighbour
  has the same colour. It is not a full morphological opening or majority filter.
  BoundedCandidates uses separate four-connected red/blue union tables, up to eight
  provisional labels per colour, never recycled within a frame. An overflow invalidates
  the whole candidate frame. Minimum area is 32. Candidate centres are bounding-box midpoints.
  The native computations run at camera PCLK; the existing rotated display diagnostics
  remain in the 25 MHz display domain and are independent of the captured candidate outputs.

SAME-FRAME SNAPSHOT
  Course FrameGrab MODE0 stores native 320x240 RGB565 before segmentation or VGA rotation.
  N_RESULTS=77: all raw centroid fields and all 8 red + 8 blue candidate slots are captured,
  including validity/error/overflow flags and expected/raw/candidate frame IDs.
  At the closing camera frame_start the integration registers the completed-frame packet.
  The existing frame_snap latches it at the next raw pixel, as required by its contract.
  Seen flags and exact ID equality make frame pairing explicit; zero is a valid wrapped ID.
  A valid pair can still contain an algorithmically invalid frame: inspect raw/candidate
  validity and error/overflow flags, not only the pair flag.
  No result publication is treated as stale success. Early boundaries can yield pair=false.
  Field layout, bit flags, byte order, and offsets are defined in packet_schema.json.
  The course five-word frame_stats example is not instantiated or used by this project.

BOARD CONTROLS (UNCHANGED FROM CALIBRATION)
  KEY0 resets camera, display, native processing, and snapshot capture.
  KEY1 captures; LEDR3 holds snapshot-ready, LEDR4 indicates busy.
  LEDR0 configured, LEDR1 SCCB error/retry, LEDR2 frame toggle. LEDR5..9 zero.
  SW2:SW1: 00 fixed RGB, 01 ratio RGB, 10 HSV, 11 fixed RGB fallback.
  SW3 display mask overlay; SW4 fixed-ROI calibration view. SW0 unused.
  KEY2/3 unused; HEX0/1/2 blank.
  Display and native selectors debounce independently in their respective domains;
  the captured native mode tag is authoritative for replay, not instantaneous switches.

CAMERA ORIENTATION AND CAPTURE
  This pipeline requires CAMERA_FPS=25: the original camera configuration selects
  CLKRC 0x81 (prescaler/2), DBLV 0x4A (PLLx4), and matching banding-filter values.
  Nominal/expected PCLK is 20 MHz from the configured prescaler and 10 MHz XCLK;
  the SDC checks a 50 ns PCLK period. Physical PCLK frequency has not been measured.
  The top includes a synthesis elaboration guard rejecting any FPS override other
  than 25. Course ov7670_config is unchanged; only its top-level FPS parameter changes.
  The initial 40 MHz/50 FPS implementation failed setup timing (-12.215 ns), was never
  programmed, and is retained only as failure-report evidence. No multicycle timing
  exception was used to hide that failure. See the new build report for 25 FPS timing.
  The first 25 FPS placement also failed fast-corner SCCB hold by 0.034 ns and was never
  programmed. Fitter-only closure requests all-path hold optimization, multicorner
  optimization, Standard Fit, and seed 2; the final report records the actual result.
  These are supported Quartus 18.1 assignments. The tested processing RTL and timing
  exceptions were unchanged for that refit. Both failed attempts remain report evidence.
  Calibration captures from the separate 50 FPS build have a different exposure limit;
  assess colour thresholds again with this 25 FPS pipeline under the intended lighting.
  Camera MVFP=0x07 remains unchanged. VGA uses CCW90 portrait display.
  Raw capture and all candidate coordinates remain native unrotated 320x240.
  Use the course decoder with the matching replay metadata:
    quartus_stp -t tcl/grab_jtag.tcl NEW_CAPTURE_DIRECTORY --mvfp 0x07
  Course tools/grab.py checks the complete GRAB CRC and produces pixels plus all 77
  result words in results.json. Decode those words according to packet_schema.json.
  Its default --mvfp 0x37 is different; always pass 0x07 for this project.

GPIO AND BUILD
  Only camera GPIO_1[10..25] is connected to active camera logic. GPIO_1[0..9] and
  [26..35] are explicitly high impedance; noncamera pull-ups are removed.
  All other unused device pins are reserved AS INPUT TRI-STATED.
  Open quartus/PartAPipeline.qpf with Quartus 18.1 or run from its quartus directory:
    quartus_sh --flow compile PartAPipeline
  The Qsys VGA IP is generated automatically. Compilation should use an isolated work
  copy so this deliverable keeps original sources separate from generated compiler files.
  Sources are based on the fixed calibration source plus separately reviewed Part A
  modules copied from the project Git working tree. See provenance.json when finalized.
