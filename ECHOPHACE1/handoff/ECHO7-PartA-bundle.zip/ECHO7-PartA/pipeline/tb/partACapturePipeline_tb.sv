`timescale 1ns/1ps
// ECHO-7 Part A | Human owner: Member A (name/SID pending).
// AI-assisted by OpenAI Codex; independent hand-calculated rectangular scenes.
// Run with Verilator so the course snapshot RAM/probes use their simulation models.
module partACapturePipeline_tb;
    localparam int N=77, PIX0=7+2*N, CRC_ADDR=PIX0+320*240;
    logic pclk=0;
    always #5 pclk=~pclk;
    logic reset=1, camera_frame_start=0, px_valid=0, trigger=0;
    logic [15:0] pixel=0;
    logic [9:0] px_x=0;
    logic [8:0] px_y=0;
    logic [3:0] control_async=0;
    logic [N*32-1:0] snapshot_results, first_packet;
    wire snap_busy,snap_ready;
    int checks=0;

    partACapturePipeline #(.W(320),.H(240),.CAP(8),.MIN_AREA(32),.CONTROL_STABLE_CYCLES(4)) dut(.*);
    frame_snap #(.MODE(0),.N_RESULTS(N)) snap_u (
        .pclk, .reset, .frame_start(camera_frame_start), .px_valid, .pixel,
        .x(px_x), .y(px_y), .results(snapshot_results), .trigger,
        .busy(snap_busy), .ready(snap_ready));

    function automatic logic [31:0] word_at(input int index);
        return snapshot_results[32*(N-1-index)+:32];
    endfunction
    task automatic expect_word(input int index,input logic [31:0] value,input string reason);
        checks++;
        if(word_at(index)!==value)
            $fatal(1,"FAIL %s word%0d got%08x expected%08x",reason,index,word_at(index),value);
    endtask
    task automatic idle(input int n);
        for(int i=0;i<n;i++)begin
            @(negedge pclk);px_valid=0;camera_frame_start=0;
            // Invalid-cycle coordinate/data noise must not enter the classifier.
            px_x=1023;px_y=511;pixel=16'hf800;
            @(posedge pclk);#1;
        end
    endtask
    task automatic boundary;
        @(negedge pclk);px_valid=0;camera_frame_start=1;
        @(posedge pclk);#1;
        @(negedge pclk);camera_frame_start=0;
    endtask
    // Native frame1 is black except three disjoint 8x8 rectangles. Dark red is
    // below FixedRGB's160 minimum but above RatioRGB's80 minimum: R=123,G=B=0.
    // Frame2+ uses grey background, so snapshot memory proves which frame was kept.
    function automatic logic [15:0] scene(input int x,input int y,input int frame_n);
        if(x>=10 && x<=17 && y>=20 && y<=27)return 16'hf800;
        if(x>=100 && x<=107 && y>=80 && y<=87)return 16'h001f;
        if(x>=50 && x<=57 && y>=40 && y<=47)return 16'h7800;
        return frame_n==1 ? 16'h0000 : 16'h39e7;
    endfunction
    task automatic send_sensor_frame(input int frame_n,input bit malformed,
                                      input bit change_mode,input bit check_latch);
        logic [15:0] value;
        bit dropped;
        for(int y=0;y<480;y++)begin
            for(int x=0;x<640;x++)begin
                // Deliberately coloured discarded sensor pixels detect bad decimation.
                if((x%2)!=0 || (y%2)!=0)value=((x+y)%3)==0?16'hf800:16'h001f;
                else value=scene(x/2,y/2,frame_n);
                dropped=malformed && x==40 && y==0; // one background kept pixel omitted
                @(negedge pclk);
                px_valid=!dropped;pixel=value;px_x=10'(x);px_y=9'(y);
                if(change_mode && x==0 && y==60)control_async=4'b0001;
                @(posedge pclk);#1;
                if(check_latch && x==0 && y==0)begin
                    checks++;
                    if(snap_u.results_q!==first_packet)
                        $fatal(1,"FAIL FrameGrab did not latch prior-frame packet at next first pixel");
                end
                if(x%31==30)idle(1);
            end
            idle(17);
        end
        idle(128);
    endtask
    task automatic expect_candidate(input int slot,input bit blue,input int xmin,input int xmax,
                                     input int ymin,input int ymax,input int cx,input int cy);
        int base;
        base=(blue?45:13)+4*slot;
        // Removing only the causal top-left corner of an8x8 rectangle leaves63.
        expect_word(base,32'h8000003f,"candidate valid/area");
        expect_word(base+1,{16'(xmin),16'(xmax)},"candidate x bounds");
        expect_word(base+2,{16'(ymin),16'(ymax)},"candidate y bounds");
        expect_word(base+3,{16'(cx),16'(cy)},"candidate bbox midpoint");
    endtask
    task automatic check_packet(input int frame_n,input int mode,input bit valid_frame);
        int red_n;
        red_n=mode==0?1:2;
        expect_word(0,32'h45504131,"magic");expect_word(1,1,"version");
        expect_word(2,32'(frame_n),"native SOP id");
        expect_word(3,32'(frame_n),"raw SOP id");expect_word(4,32'(frame_n),"candidate SOP id");
        // same-frame/seen/IDs can be true on malformed frames; validity remains separate.
        expect_word(5,valid_frame?32'h0000e09f:32'h0000812f,"publication flags");
        expect_word(6,{16'd320,16'd240},"native geometry");
        expect_word(7,32'h00002080|32'(mode),"frame-qualified configuration");
        expect_word(8,32'(red_n*64),"raw red area");expect_word(10,64,"raw blue area");
        if(valid_frame)begin
            expect_word(9,mode==0?{16'd13,16'd23}:{16'd33,16'd33},"raw red exact centroid floor");
            expect_word(11,{16'd103,16'd83},"raw blue exact centroid floor");
            expect_word(12,32'h10|32'(red_n),"candidate counts");
            expect_candidate(0,0,10,17,20,27,13,23);
            if(mode!=0)expect_candidate(1,0,50,57,40,47,53,43);
            expect_candidate(0,1,100,107,80,87,103,83);
        end else expect_word(12,0,"malformed candidate counts suppressed");
        for(int i=0;i<8;i++)begin
            if(!valid_frame || i>=red_n)begin
                checks++;
                if(word_at(13+4*i)&32'h80000000)$fatal(1,"FAIL unexpected valid red candidate%0d",i);
            end
            if(!valid_frame || i>=1)begin
                checks++;
                if(word_at(45+4*i)&32'h80000000)$fatal(1,"FAIL unexpected valid blue candidate%0d",i);
            end
        end
    endtask
    // Bit-by-bit CRC over complete16bit words, independent of frame_snap's
    // byte-folding function. CRC-16/CCITT-FALSE polynomial1021, initialffff.
    function automatic logic [15:0] crc_word(input logic [15:0] previous,input logic [15:0] data);
        logic [15:0] crc;
        logic feedback;
        crc=previous;
        for(int bit_n=15;bit_n>=0;bit_n--)begin
            feedback=crc[15]^data[bit_n];
            crc={crc[14:0],1'b0};
            if(feedback)crc=crc^16'h1021;
        end
        return crc;
    endfunction
    task automatic check_snapshot;
        logic [15:0] crc;
        logic [31:0] saved_word;
        if(!snap_ready || snap_busy)$fatal(1,"FAIL snapshot not ready after following full frame");
        if(snap_u.ram_u.mem[0]!==16'h4752 || snap_u.ram_u.mem[1]!==16'h4142 ||
           snap_u.ram_u.mem[2]!==16'd1 || snap_u.ram_u.mem[3]!==16'd320 ||
           snap_u.ram_u.mem[4]!==16'd240 || snap_u.ram_u.mem[5]!==16'd1 ||
           snap_u.ram_u.mem[6]!==16'd77)$fatal(1,"FAIL FrameGrab header");
        checks+=7;
        for(int i=0;i<N;i++)begin
            saved_word={snap_u.ram_u.mem[7+2*i],snap_u.ram_u.mem[8+2*i]};
            checks++;
            if(saved_word!==first_packet[32*(N-1-i)+:32])$fatal(1,"FAIL snapshot resultword%0d",i);
        end
        for(int y=0;y<240;y++)for(int x=0;x<320;x++)begin
            checks++;
            if(snap_u.ram_u.mem[PIX0+y*320+x]!==scene(x,y,1))
                $fatal(1,"FAIL captured native RGB565 x%0d y%0d (odd-pixel contamination or wrong frame)",x,y);
        end
        crc=16'hffff;
        for(int i=0;i<CRC_ADDR;i++)crc=crc_word(crc,snap_u.ram_u.mem[i]);
        checks++;
        if(snap_u.ram_u.mem[CRC_ADDR]!==crc)$fatal(1,"FAIL snapshot CRC got%04x expected%04x",snap_u.ram_u.mem[CRC_ADDR],crc);
    endtask
    initial begin
        idle(3);@(negedge pclk);reset=0;
        trigger=1;idle(10);trigger=0;idle(10);
        boundary();
        if(word_at(5)&1)$fatal(1,"FAIL startup stale packet qualified same-frame");
        send_sensor_frame(1,0,1,0);boundary();check_packet(1,0,1);
        first_packet=snapshot_results;
        send_sensor_frame(2,0,0,1);check_snapshot();boundary();check_packet(2,1,1);
        send_sensor_frame(3,1,0,0);boundary();check_packet(3,1,0);
        send_sensor_frame(4,0,0,0);boundary();check_packet(4,1,1);
        $display("PASS partACapturePipeline: %0d checks; full640x480 sensor streams, native geometry, ignored odd pixels, switch frame qualification, malformed recovery, same-frame77word snapshot and independentCRC",checks);
        $finish;
    end
    initial begin #30ms;$fatal(1,"FAIL partACapturePipeline watchdog");end
endmodule
