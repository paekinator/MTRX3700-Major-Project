# ECHO-7 Part A front end

Open `quartus/PartAPipeline.qpf` for the new camera-only project. It adds native
320×240 red/blue processing and a 77-word same-frame snapshot packet to the existing
camera/display diagnostics. Its noncamera GPIO outputs are disabled. The original
`Camera.qpf` project remains separate. No motion or CNN is included in this project.

This Part A top requires the supported **25 FPS** camera setting, with nominal
20 MHz PCLK and a matching 50 ns constraint. The earlier 50 FPS / 40 MHz attempt
failed setup timing by 12.215 ns and was never programmed. An elaboration guard
rejects higher-FPS overrides in this project. The supplied camera configuration
itself is unchanged; it selects the original prescaler and banding-filter values
for FPS=25. Physical frequency still requires measurement if used as a measured
performance claim. The longer exposure limit also means colour calibration should
use the final 25 FPS image.

The path is RGB565 → existing fixed/ratio/HSV selector → raw colour centroid and,
in parallel, causal mask cleanup → bounded 4-connected candidates. Processing runs
in camera PCLK. The supplied framebuffer crosses into the display clock domain;
recorded processing results stay in PCLK beside the supplied JTAG snapshot logic.

`SW2:SW1` selects fixed RGB (`00`), ratio RGB (`01`), HSV (`10`) or fixed fallback
(`11`). Selection is qualified at each stream's SOP. `SW3` controls the display
mask; `SW4` selects display ROI calibration. Neither restricts native candidates to
the display ROI. `KEY0` resets; `KEY1` captures. Decode using camera MVFP `0x07`.

## Interfaces and limits

- All measurements use unrotated native coordinates x=0…319, y=0…239. VGA rotates
  and scales the picture; its pixel coordinates cannot be used interchangeably.
- Raw centroids use every classified pixel of each colour and exact floor(sum/area).
  Distractors therefore affect this deliberately simple baseline.
- Cleanup retains a foreground pixel if its raw left or upper neighbour has the
  same colour. It removes an isolated speck and a rectangle's first corner pixel;
  it is not a 3×3 opening. Raw neighbour history advances only on valid pixels.
- Each candidate has exact cleaned-pixel area, bounds and floor((min+max)/2) centre.
  Its centre is a bounding-box midpoint, not a pixel centroid.
- CAP=8 limits provisional seeds per colour, without reuse after union. MIN_AREA=32
  filters after allocation. Fragmentation/tiny objects can overflow before area
  filtering; cleanup itself can turn one rectangle into two provisional seeds.
  Either-colour overflow suppresses every candidate valid/count in that frame.
- Candidate finalization takes eight scan clocks plus publication. Raw centroid
  division takes about thirty clocks. Camera blanking provides the normal margin;
  malformed/overlapping frames are flagged and invalidated. Frame IDs count accepted
  SOPs modulo 65,536; zero after wrap is legal.

`packet_schema.json` specifies the 77 unsigned words. Word5 bit0 proves result
association with the captured frame; it does not prove candidate validity. Bit7
is candidate-frame validity; counts and Member B's geometry/identity checks remain
necessary. Raw frame/colour validity is separate. Results are held at frame_start
and the supplied snapshot samples that packet at the next raw pixel. This project
does not add a Member B clock crossing; consume the packet in PCLK or add a tested
held-payload handshake when connecting another domain.

## Tests and recorded replay

On Linux/Ed with standard Verilator 5.050, make, C++ and Python NumPy/Pillow:

```sh
bash run_part_a_tests.sh
```

This Part A runner creates fresh build/log directories, runs Python model/checker
tests, both module benches and the front-end/snapshot integration bench, then
requires a temporary deliberately wrong `cx+1` implementation to fail. It has a
300-second overall deadline. It does not test the complete robot. Its Linux/Ed CLI
route has syntax checks only; actual native Windows Verilator 5.050 execution used
the isolated CMake/Zig runtime documented with the delivered verification logs.

After programming PartAPipeline and pointing at a target:

```sh
quartus_stp -t tcl/grab_jtag.tcl captures/trial_001 --mvfp 0x07
python tools/grab.py --file captures/trial_001/dump.bin --out captures/trial_001 --mvfp 0x07
python tools/part_a/check_hardware_packet.py captures/trial_001
```

The checker independently verifies transport CRC and recomputes fixed/ratio/HSV
masks, cleanup, raw centroids and bounded components from the saved RGB565 pixels.
It rejects the earlier five-word course/calibration captures as Part A evidence.
A numerical PASS with candidate overflow proves agreement about an invalid frame;
it does not establish reliable target detection. Printed red/blue, distractor,
lighting and repeatability trials remain necessary.

New code is AI-assisted. See `OWNERS.md` for origins and pending human name/SID
review. The supplied FrameGrab modules/tools retain their original notices.
