FINAL PART A RECORDED-INPUT REPLAY: PASS

17 real recorded inputs, in the exact agreed order, run as16+1 with the existing
MAX16 Verilator binary. Batch01 passed251 packet/descriptor checks; batch02
passed14. Total265 checks. No rebuild, RTL/threshold/model change, full-suite
repeat or hardware operation occurred.

manifest.json contains current compiled/model source hashes, unchanged binary
hash, commands/log references and per-batch vector file hashes.
case_results.json contains every original CRC-checked measured packet, actual
hardware frame IDs, candidate descriptors, input hashes, complete independently
predicted EPA2 packets/descriptors and scene assessments.
batch01/predicted_vectors and batch02/predicted_vectors contain ALL selected
RGB565 inputs in frames.hex, modes.hex, expected.hex and detailed metadata.json.

Five original captures are EPA1 inputs. Their result words are retained as EPA1
provenance and are never presented as measured EPA2. The other12 are actual EPA2
captures. The exporter never uses old result words to calculate predictions.
Actual frame IDs stay distinct from batch-local replay sequence IDs. In
particular, the final blank's actual frame23467/CRCee14 is replay sequence1 of
batch02. All12 measured EPA2 public metadata, raw centroids and valid descriptor
multisets agree with independent predictions. First12 vector prefixes remain
byte-identical to the preceding12-case evidence.

Retained cases include:
  Case09 paired_v2_handheld_003: expected invalid active-label overflow,0R/0B.
  Case13 red_distractor_v2_001: expected invalid completed-output overflow,0R/0B.
  Case14 red_single_v2_001: unsuccessful square fixture, measured only1R/1B.
  Case15 red_single_v2_002: successful red separation,2R/1B; actual frame17280.
  Case16 blue_single_v2_001: successful blue separation,1R/2B; actual frame19498.
  Case17 blank_v2_001: valid0R/0B; one raw blue pixel removed by cleanup.

Simulation PASS means agreement with expected numerical behavior, including the
two invalid overflow frames. It does not mean all17 scenes are suitable marker
fixtures or establish complete-robot R6 compliance.

An initial aggregate-helper attempt failed after the successful16-case simulator
run because equal descriptor dictionaries were sorted by differing insertion
order. The work helper was corrected to compare named fields, then reused the
unchanged successful16-case log and ran the blank-only batch. The original
aggregate-only FAIL is preserved in attempt01_manifest.json. Both simulator
logs passed; no RTL was changed to obtain the final aggregate PASS.
