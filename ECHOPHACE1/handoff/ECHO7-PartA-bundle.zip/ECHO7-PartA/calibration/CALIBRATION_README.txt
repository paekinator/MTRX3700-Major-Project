ECHO-7 CAMERA CALIBRATION ONLY
AI-assisted integration: OpenAI Codex. Student owner/SID: PENDING human assignment/review.
This build is for colour/ROI calibration and raw snapshots. It is not completed Part A.
It has no candidate association/classification, motion requests, chassis UART, sonar,
Arduino, or IR control logic. No CNN is included.

Controls (stock ECHO camera orientation retained):
  KEY0: reset camera configuration, display processing, and snapshot capture.
  KEY1: capture next complete raw frame (also requestable over USB-Blaster JTAG).
  KEY2/KEY3: unused. HEX0/1/2: blank.
  SW4=1: fixed ROI calibration diagnostic view; SW4=0: normal diagnostics.
  SW3: segmentation-mask overlay enable (inside the ROI in calibration view).
  SW2:SW1 = 00 fixed RGB, 01 ratio RGB, 10 HSV, 11 fixed RGB fallback.
  SW0: unused. Switch values are latched at frame boundaries.
  LEDR0: camera configured. LEDR1: SCCB acknowledgement error/retry.
  LEDR2: frame toggle. LEDR3: complete snapshot held. LEDR4: snapshot busy.
  LEDR5..9: zero.

GPIO drive audit:
  GPIO_1[10]=camera PWDN; [11]=camera reset; [20]=10 MHz XCLK;
  [25]=SIO_C; [24]=open-drain SIO_D with existing SCCB pull-ups.
  [12..19], [21..23] are camera data/PCLK/HREF/VSYNC inputs.
  [0..9] and [26..35] are explicitly Z; their previous safety pull-ups are removed.
  All other unused device pins are reserved AS INPUT TRI-STATED.
  Camera mapping is unchanged from ECHOPHACE1; do not infer wiring from this file.

Raw capture:
  frame_snap MODE=0 stores 320x240 RGB565 before segmentation and CCW90 VGA rotation.
  Camera register MVFP remains 0x07. Pass --mvfp 0x07 to tools/grab.py or the
  provided tcl/grab_jtag.tcl decoder option; the course tool default 0x37 is different.
  The stored frame.png is native capture coordinates, not the rotated VGA image.
  Snapshot metadata contains the course example's five frame_stats words:
  frame number, red-pixel count, red x-sum, red y-sum, grayscale sum.
  They are independent of ECHO's display ROI statistics and segmentation thresholds.
  Course tools remain unmodified; their original comments and attribution are retained.

Build:
  Open quartus/PartACalibration.qpf in Quartus 18.1, or run from quartus:
    quartus_sh --flow compile PartACalibration
  Quartus generates the VGA Qsys IP when compiling.
  The delivered sources are kept clean; validation build occurs in work/parta_calibration_build/project.
  See provenance.json for source hashes and build_validation.json for measured results.
  No board programming is performed by this build step.
